package liveable;

public abstract class Creature {
    protected String name = "noname";
    String getName(){return name;}
}
