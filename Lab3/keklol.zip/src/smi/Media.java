package smi;

public interface Media {
    void say();
    static final String message = "Карлсон у себя дома";
}
