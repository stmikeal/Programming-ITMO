java -cp bin tostart.Starter
