javac -d bin src/liveable/Creature.java
javac -d bin -cp bin src/liveable/Petable.java
javac -d bin -cp bin src/liveable/Mood.java
javac -d bin -cp bin src/liveable/Carlson.java
javac -d bin -cp bin src/liveable/Puppy.java
javac -d bin -cp bin src/liveable/Human.java

javac -d bin src/smi/Media.java
javac -d bin -cp bin src/smi/News.java
javac -d bin -cp bin src/smi/Magazine.java
javac -d bin -cp bin src/smi/TV.java

javac -d bin -cp bin src/liveable/Parent.java

javac -d bin -cp bin src/tostart/Starter.java
