package tostart;

import liveable.*;

public class Starter {
    public static void main(String[] args) {
        System.out.println("------------------------------------");
        Carlson carlson = new Carlson();
        Human lilBoy = new Human(carlson, "Малыш");
        Human bosse = new Human(carlson, "Боссе");
        Human betan = new Human(carlson, "Бетан");
        Puppy bim = new Puppy(lilBoy, "Бим-Бо");
        Parent mom = new Parent(carlson, "Мама");
        Parent dad = new Parent(carlson, "Папа");
        System.out.println("----------------------------------");
        carlson.buzzing();
        lilBoy.say();
        bosse.say();
        betan.say();
        bim.bark();
        mom.say();
        dad.say();
        System.out.println("-----------------------------------");
        while (bosse.getMood()==Mood.UNLIKE||betan.getMood()==Mood.UNLIKE||
                mom.getMood()==Mood.UNLIKE||dad.getMood()==Mood.UNLIKE){
            System.out.println("@\nПрошло немного времени...");
            bosse.tryToChange();
            betan.tryToChange();
            mom.tryToChange();
            dad.tryToChange();
        }
        System.out.println("------------------------------------");
        mom.imagine();
        System.out.println("------------------------------------");
        dad.imagine();
        System.out.println("------------------------------------");
    }  
}
