package liveable;

public interface Petable {
    String getOwnerName();
}
