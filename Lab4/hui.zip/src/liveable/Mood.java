package liveable;

public enum Mood {LIKE, UNLIKE, NEUTRAL}
